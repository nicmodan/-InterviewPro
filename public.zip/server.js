const express = require('express');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3003;

app.use(express.json());

// ── OPay Cashier proxy ────────────────────────────────────────────────────────
// The browser cannot call OPay directly (CORS). This endpoint forwards the
// request server-side and returns the response to the client.
app.post('/api/opay/create-order', async (req, res) => {
  const isSandbox  = req.body.isSandbox !== false;   // default: sandbox
  const endpoint   = isSandbox
    ? 'https://sandboxapi.opaycheckout.com/api/v1/international/cashier/create'
    : 'https://api.opaycheckout.com/api/v1/international/cashier/create';

  const { publicKey, merchantId, ...payload } = req.body;

  if (!publicKey || !merchantId) {
    return res.status(400).json({ error: 'Missing publicKey or merchantId' });
  }

  try {
    const opayRes = await fetch(endpoint, {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${publicKey}`,
        'MerchantId':    merchantId,
      },
      body: JSON.stringify(payload),
    });

    const rawText = await opayRes.text();
    let data;
    try {
      data = JSON.parse(rawText);
    } catch {
      console.error('[OPay proxy] Non-JSON response from OPay:', rawText.slice(0, 300));
      return res.status(502).json({ error: 'OPay returned a non-JSON response', detail: rawText.slice(0, 300) });
    }
    return res.status(opayRes.status).json(data);
  } catch (err) {
    console.error('[OPay proxy] fetch error:', err);
    return res.status(502).json({ error: 'Failed to reach OPay API', detail: err.message });
  }
});

// ── OPay payment callback (server-to-server notification from OPay) ──────────
// OPay POSTs payment status here after the user completes/fails payment.
// Must return { "code": "00000" } to acknowledge receipt, otherwise OPay retries.
app.post('/api/opay/callback', (req, res) => {
  const payload = req.body;
  console.log('[OPay callback] received:', JSON.stringify(payload));
  // TODO: verify the payload signature using your OPay secret key,
  // then update the payment record in your database accordingly.
  // For now we acknowledge receipt so OPay stops retrying.
  res.status(200).json({ code: '00000', message: 'success' });
});

// Serve all static files from /public
app.use(express.static(path.join(__dirname, 'public')));

// Guard: any unmatched /api/* route returns JSON 404 — never HTML
app.all('/api/*', (_req, res) => {
  res.status(404).json({ error: 'API route not found' });
});

// Catch-all → always return index.html (handles page refresh / direct URLs)
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✦  God's Celebrities running → http://localhost:${PORT}`);
});
